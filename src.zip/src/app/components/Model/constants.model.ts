export class Constants{

    tableName:any;
    serviceType :any;
    sourceurl: any;
    connectiontimeout: any;
    readtimeout: any;
    targetheaders: any;
 
} 