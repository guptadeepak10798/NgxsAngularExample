export class Logs{

    id:any;
    requestdata :any;
    responsedata: any;
    updatedtime: any;
    createdtime: any;
    username: any;
    clientid: any;
    transactionid: any;
} 