import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';

import { Router } from '@angular/router';
import { SharedServiceService } from '../../services/shared-service.service';

@Component({
  selector: 'app-log-dashboard',
  templateUrl: './log-dashboard.component.html',
  styleUrls: ['./log-dashboard.component.css']
})
export class LogDashboardComponent implements OnInit {

  cards: any[] = [];
  searchText: any;
  data: any;
  filteredData: any[] = [];
  originalData: any[] = [];
  searchPerformed: boolean = false;

  constructor(private location: Location, private service: SharedServiceService, private router: Router) { }

  ngOnInit(): void {
    this.getDetails();
    this.originalData = this.cards;
  }
  //  cards = [
  //       {
  //         "tableName": "pff_constant",
  //         "serviceType": "createFinance", 
  //       },
  //       {
  //         "tableName": "pff1_constant",
  //         "serviceType": "getdocument",
  //       }
  //     ]

  // openData(index: number) {
  //   const card = this.cards[index];
  //   console.log("element", card);

  // }


  // getDetails() {
  //   console.log("Into the getv method");
  //   return this.service.getServiceLog().subscribe((data: any) => {
  //     console.log("response API data==>", data);
  //     const table_name = data.table_name;
  //     const servicetype = data.servicetype;
  //     console.log("botthhh data herereee", table_name, servicetype );


  //     let card = {
  //       parent: 'Table Name',
  //       data: {
  //         table_name: table_name,
  //         servicetype: servicetype
  //       }
  //     };

  //     this.cards.push(card);
  //     console.log("API data here: ", this.cards);
  //   });
  // }
  public loading = false;

  getDetails() {
    console.log("Into the getv method");
    this.loading = true;

    return this.service.getServiceLog().subscribe(data => {
      for (let parentName in data) {
        if (data.hasOwnProperty(parentName)) {
          let childObjects = data[parentName];
          for (let childName in childObjects) {
            if (childObjects.hasOwnProperty(childName)) {
              let childObject = childObjects[childName];
              let card = {
                parent: parentName,
                child: childName,
                data: childObject
              };
              this.cards.push(card);
              this.loading = false;

            }
          }
        }
      }

      console.log("data==>", data);
      console.log("API data here ssssss: ", this.cards);
    });

  }


  // openData(index: number) {
  //   const card = this.cards[index];
  //   console.log("element", card);
  //    this.router.navigate(['/serviceLog'], {
  //     queryParams: {
  //       tableName: card.parent,
  //       serviceType: card.child
  //     }
  //    });
  // }

  openData(index: number) {
    const filteredCards = this.searchText ? this.filteredData : this.cards;
    const card = filteredCards[index];
    console.log("element", card);
    this.router.navigate(['/serviceLog'], {
      queryParams: {
        tableName: card.parent,
        serviceType: card.child
      }
    });
  }

  // applyFilter() {
  //   const filterValue = this.searchText.trim().toLowerCase();
  //   this.filteredData = this.cards.filter((item: { child: string }) =>
  //     item.child.toLowerCase().includes(filterValue)
  //   );
  //   console.log("filterValue=======", this.filteredData);
  // }

  applyFilter() {
    const filterValue = this.searchText.trim().toLowerCase();
    this.filteredData = this.cards.filter((item: { child: string }) =>
      item.child.toLowerCase().includes(filterValue)
    );
    console.log("filterValue=======", this.filteredData);
    this.searchPerformed = true;
    console.log("filterValue length=======", this.filteredData.length);
  }

  goBack(): void {
    this.location.back();
  }



}
