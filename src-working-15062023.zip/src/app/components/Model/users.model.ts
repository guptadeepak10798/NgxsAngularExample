export class Users{

    id:any;
    name :any;
    username: any;
    email: any;
    password: any;
    contact_no: any;
    role: any;
} 